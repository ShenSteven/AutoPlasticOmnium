using System;
using Vector.Tools;
using Vector.CANoe.Runtime;
using Vector.CANoe.Sockets;
using Vector.CANoe.Threading;
using Vector.Diagnostics;
using Vector.Scripting.UI;
using Vector.CANoe.TFS;
using Vector.CANoe.VTS;
using NetworkDB;
using CaplTestCases;

public class net : StructuredTestModule
{
    /************************************************************************/
    /* The main function of the test module controls the sequence of the test
     * cases. It is required to override this function.
    /************************************************************************/
    public override void StructuredMain()
    {
        TestGroupBegin("InitTest", "Init test variables,environment. ");
        InitTestVariables2();
        TestGroupEnd();

        TestGroupBegin("1.DataLinkLayerTest", "Data Link Layer Test");
        TG1_TC01_SC01_Voltage_Rising_Test();
        TG1_TC01_SC02_Voltage_Falling_Test();
        TG1_TC04_SC01_Over_Voltage_Range_Test();
        TG1_TC05_SC01_Low_Voltage_Range_Test();
        TestGroupEnd();

        TestGroupBegin("2.DataLinkLayerTest", "Data Link Layer Test");
        TG2_TC01_SC01_Length_of_SyncBreak_Area_Test();
        TG2_TC02_SC01_Length_of_SyncDel_Area_Test();
        TG2_TC03_SC01_Length_of_Message_Header_Area_Test();
        TG2_TC05_SC01_LIN_Slave_Node_Baudrate_Sync_Test();
        TG2_TC06_SC01_LIN_Slave_Node_ChecksumTest_Enhance();
        TG2_TC06_SC02_LIN_Slave_Node_ChecksumTest_Classical();
        TestGroupEnd();


        TestGroupBegin("3.NetworkManage", "Network Manage Test. Sleep/Wakeup");
        TG3_TC01_SC01_LIN_Slave_Node_Receive_Sleep_Commond_Test();
        TG3_TC01_SC02_LIN_Slave_Node_Receive_Nonlicet_Sleep_Commond_Test();
        TG3_TC02_SC01_LIN_Slave_Node_Receive_Wakeup_Signal_Test();
        TG3_TC04_SC01_LIN_Slave_Node_wait_4S_under_Bus_Idle_Test();
        TestGroupEnd();

        TestGroupBegin("5.FaultError", "Fault management Test");
        TG5_TC01_SC01_Syn_Field_Error_Test();
        TG5_TC01_SC02_Syn_Field_Stop_bit_Error_Test();
        TG5_TC02_SC01_ID_Parity_Field_Error_Test();
        TG5_TC03_SC01_Checksum_Error_Test();
        TG5_TC04_SC01_Data_Field_Error();
        TG5_TC04_SC02_Data_Field_Stop_Bit_Error_Test();
        TestGroupEnd();

    }

    [TestCase("TG5_TC04_SC02_Data_Field_Stop_Bit_Error_Test")]
    private void TG5_TC04_SC02_Data_Field_Stop_Bit_Error_Test()
    {
        //LINSlaveConformanceTest2_1.TG5_TC04_SC02_Data_Field_Stop_Bit_Error_Test();
    }

    [TestCase("TG5_TC04_SC01_Data_Field_Error")]
    private void TG5_TC04_SC01_Data_Field_Error()
    {
        //LINSlaveConformanceTest2_1.TG5_TC04_SC01_Data_Field_Error();
    }

    [TestCase("TG5_TC03_SC01_Checksum_Error_Test")]
    private void TG5_TC03_SC01_Checksum_Error_Test()
    {
        //LINSlaveConformanceTest2_1.TG5_TC03_SC01_Checksum_Error_Test();
    }

    [TestCase("TG5_TC02_SC01_ID_Parity_Field_Error_Test")]
    private void TG5_TC02_SC01_ID_Parity_Field_Error_Test()
    {
        //LINSlaveConformanceTest2_1.TG5_TC02_SC01_ID_Parity_Field_Error_Test();
    }

    [TestCase("TG5_TC01_SC02_Syn_Field_Stop_bit_Error_Test")]
    private void TG5_TC01_SC02_Syn_Field_Stop_bit_Error_Test()
    {
        //LINSlaveConformanceTest2_1.TG5_TC01_SC02_Syn_Field_Stop_bit_Error_Test();
    }

    [TestCase("TG5_TC01_SC01_Syn_Field_Error_Test")]
    private void TG5_TC01_SC01_Syn_Field_Error_Test()
    {
        //LINSlaveConformanceTest2_1.TG5_TC01_SC01_Syn_Field_Error_Test();
    }

    [TestCase("TG3_TC04_SC01_LIN_Slave_Node_wait_4S_under_Bus_Idle_Test")]
    private void TG3_TC04_SC01_LIN_Slave_Node_wait_4S_under_Bus_Idle_Test()
    {
        //LINSlaveConformanceTest2_1.TG3_TC04_SC01_LIN_Slave_Node_wait_4S_under_Bus_Idle_Test();
    }

    [TestCase("TG3_TC02_SC01_LIN_Slave_Node_Receive_Wakeup_Signal_Test")]
    private void TG3_TC02_SC01_LIN_Slave_Node_Receive_Wakeup_Signal_Test()
    {
        //LINSlaveConformanceTest2_1.TG3_TC02_SC01_LIN_Slave_Node_Receive_Wakeup_Signal_Test();
    }

    [TestCase("TG3_TC01_SC02_LIN_Slave_Node_Receive_Nonlicet_Sleep_Commond_Test")]
    private void TG3_TC01_SC02_LIN_Slave_Node_Receive_Nonlicet_Sleep_Commond_Test()
    {
        //LINSlaveConformanceTest2_1.TG3_TC01_SC02_LIN_Slave_Node_Receive_Nonlicet_Sleep_Commond_Test();
    }

    [TestCase("TG3_TC01_SC01_LIN_Slave_Node_Receive_Sleep_Commond_Test")]
    private void TG3_TC01_SC01_LIN_Slave_Node_Receive_Sleep_Commond_Test()
    {
        //LINSlaveConformanceTest2_1.TG3_TC01_SC01_LIN_Slave_Node_Receive_Sleep_Commond_Test();
    }

    [TestCase("TG2_TC06_SC02_LIN_Slave_Node_ChecksumTest_Classical")]
    private void TG2_TC06_SC02_LIN_Slave_Node_ChecksumTest_Classical()
    {
        //LINSlaveConformanceTest2_1.TG2_TC06_SC02_LIN_Slave_Node_ChecksumTest_Classical();
    }

    [TestCase("TG2_TC06_SC01_LIN_Slave_Node_ChecksumTest_Enhance")]
    private void TG2_TC06_SC01_LIN_Slave_Node_ChecksumTest_Enhance()
    {
        //LINSlaveConformanceTest2_1.TG2_TC06_SC01_LIN_Slave_Node_ChecksumTest_Enhance();
    }

    [TestCase("TG2_TC05_SC01_LIN_Slave_Node_Baudrate_Sync_Test")]
    private void TG2_TC05_SC01_LIN_Slave_Node_Baudrate_Sync_Test()
    {
        //LINSlaveConformanceTest2_1.TG2_TC05_SC01_LIN_Slave_Node_Baudrate_Sync_Test();
    }

    [TestCase("TG2_TC03_SC01_Length_of_Message_Header_Area_Test")]
    private void TG2_TC03_SC01_Length_of_Message_Header_Area_Test()
    {
        //LINSlaveConformanceTest2_1.TG2_TC03_SC01_Length_of_Message_Header_Area_Test();
    }

    [TestCase("TG2_TC02_SC01_Length_of_SyncDel_Area_Test")]
    private void TG2_TC02_SC01_Length_of_SyncDel_Area_Test()
    {
        //LINSlaveConformanceTest2_1.TG2_TC02_SC01_Length_of_SyncDel_Area_Test();
    }

    [TestCase("TG2_TC01_SC01_Length_of_SyncBreak_Area_Test")]
    private void TG2_TC01_SC01_Length_of_SyncBreak_Area_Test()
    {
        //LINSlaveConformanceTest2_1.TG2_TC01_SC01_Length_of_SyncBreak_Area_Test();
    }

    [TestCase("TG1_TC05_SC01_Low_Voltage_Range_Test")]
    private void TG1_TC05_SC01_Low_Voltage_Range_Test()
    {
        //LINSlaveConformanceTest2_1.TG1_TC05_SC01_Low_Voltage_Range_Test();
    }

    [TestCase("TG1_TC04_SC01_Over_Voltage_Range_Test")]
    private void TG1_TC04_SC01_Over_Voltage_Range_Test()
    {
        //LINSlaveConformanceTest2_1.TG1_TC04_SC01_Over_Voltage_Range_Test();
    }

    [TestCase("TG1_TC01_SC02_Voltage_Falling_Test")]
    private void TG1_TC01_SC02_Voltage_Falling_Test()
    {
        //LINSlaveConformanceTest2_1.TG1_TC01_SC02_Voltage_Falling_Test();
    }

    [TestCase("TG1_TC01_SC01_Voltage_Rising_Test")]
    private void TG1_TC01_SC01_Voltage_Rising_Test()
    {
        //LINSlaveConformanceTest2_1.TG1_TC01_SC01_Voltage_Rising_Test();
    }

    [TestCase("Init test Variables")]
    public void InitTestVariables2()
    {
        //LINSlaveConformanceTest21.InitTestVariables()
    }

    //[TestCase("3.1.1_Slave Receive Sleep Command")]
    //public void Slave_Sleep()
    //{

    //}

    //[TestCase("3.3.1_Slave Sleep After 4s")]
    //private void SleepAfter4s()
    //{

    //}

    //[TestCase("3.2.1_Slave Receive Wakeup Command")]
    //private void Slave_Wakeup()
    //{

    //}

    //[TestCase("5.1.1_Syn Field Error Test")]
    //public void Syn_Field_Error_Test()
    //{
    //    Report.TestStep("Start engine:");
    //    // Setting bus signal SigStart to 1:
    //    NetworkDB.LIN_Master.TST_FRAME_2_Tx_Signal1.Value = 1;
    //    // Waiting 500ms for the SigEngine signal being 1:
    //    if (Execution.Wait<NetworkDB.LIN_Master.TST_FRAME_2_Tx_Signal1>(1, 500) == 1)
    //        Report.TestStepPass("Engine is running.");
    //    else
    //        Report.TestStepFail("Engine is not running.");
    //}

    //[TestCase("5.2.1_ID Parity Field Error Test")]
    //public void ID_Field_Error_Test()
    //{

    //}


    //[TestCase("5.3.1_Checksum Error Test")]
    //public void Checksum_Error_Test()
    //{

    //}


    //[TestCase("5.4.1_Data Field Error Test")]
    //public void Data_Field_Error_Test()
    //{

    //}

    //[TestCase("2.1.1_Length of SyncBreak Area Test")]
    //public void SyncBreakLengthTest()
    //{
    //    Report.TestStep("1.Send Go-to Sleep Command.");
    //    Report.TestStep("2.Send Command,Check no repsond.");
    //    Report.TestStep("3.Send Wakeup Command.");
    //    Report.TestStep("4.Send Command,Check repsond.");
    //}

    //[TestCase("2.2.1_Length of SyncDel Area Test")]
    //public void SyncDelLengthTest()
    //{

    //}

    //[TestCase("2.3.1_Length of Message Header Area Test")]
    //public void MessageHeaderLengthTest()
    //{

    //}

    //[TestCase("2.4.1_LIN slave Node Baudrate (unsync)Test")]
    //public void Baudrate_unsync_Test()
    //{

    //}


    //[TestCase("2.5.1_LIN slave Node Baudrate (sync)Test")]
    //public void Baudrate_sync_Test()
    //{

    //}

    //[TestCase("2.6.1_LIN Slave Node ChecksumTest_Enhance")]
    //public void ChecksumTest_Enhance()
    //{

    //}

    //[TestCase("2.6.2_LIN Slave Node ChecksumTest_Classical")]
    //public void ChecksumTest_Classical()
    //{

    //}

    //[OnChange(typeof(NetworkDB.LIN_Master.TST_FRAME_2_Tx_Signal1))]
    //public void OnSignalLockState()
    //{
    //    double value = NetworkDB.LIN_Master.TST_FRAME_2_Tx_Signal1.Value;
    //    //double value = NetworkDB.
    //}

    //[OnLINFrame]
    //public void onMessage(NetworkDB.LIN_Master.TST_FRAME_2_Tx_Signal1 frame)
    //{
    //    double pos = frame.WindowPosition.Value;
    //}
    //[OnCANFrame(1, 500)]


    //public void Frame500Received(CANFrame frame)
    //{
    //    //Simple timeout: 
    //    Execution.Wait(50);
    //    //Bus signal: 
    //    Execution.Wait<EngineRunning>(1);
    //    //System variable: 
    //    Execution.Wait<SystemUnderTest.OperationMode>(2);
    //    //Environment variable: 
    //    Execution.Wait<EnvDoorLocked>(EnvDoorLocked.Locked);
    //    //Message:
    //    Execution.WaitForCANFrame(ref frame, 500);
    //}

    //[OnTimer(500)]
    //public void TimerElapsed()
    //{
    //    // msg.Send();
    //}

    //The module can also react on system variable changes:
    //[OnChange(typeof(Test_Configuration_1.RunState))]
    //public void MyIntHandler()
    //{
    //    Test_Configuration_1.RunState.Value = 1;
    //}

    //[Criterion]
    //[OnChange(typeof(AntiTheftSystemActive))]
    //[OnChange(typeof(LockState))]
    //bool AntiTheftSystemCriterion()
    //{
    //    if ((EngineRunning.Value == 0) && (LockState.Value == 1))
    //        return (AntiTheftSystemActive.Value == 1);
    //    else
    //        return (AntiTheftSystemActive.Value == 0);
    //}

    //[TestCase("Title", "Description")]
    //public void ObserveEngineState()
    //{
    //    ICheck engOn = new ValueCheck<EngineRunning>(CheckType.Observation, 1);
    //    engOn.Activate();
    //    Vector.CANoe.Threading.Execution.Wait(4000); // observation active
    //    engOn.Deactivate();

    //    ICheck check = new MyUserCheck("MyUser check", "Check DLC of message 0x64");
    //    check.Activate(); // or: check.Activate("a new title");
    //                      // ...
    //    check.Deactivate();
    //    check.Dispose();

    //    Check observeAntiTheftSystem = new Check(AntiTheftSystemCriterion);
    //    observeAntiTheftSystem.Activate();
    //    Execution.Wait(AntiTheftSystemCriterion);


    //    Criterion antiTheftSystem = new Criterion();
    //    antiTheftSystem.AddMandatory(new ValueCriterion<AntiTheftSystemActive>(0));
    //    antiTheftSystem.AddOneOf(new ValueCriterion<LockState>(0));
    //    antiTheftSystem.AddOneOf(new ValueCriterion<EngineRunning>(1));
    //    Check observeAntiTheftSystem = new Check(antiTheftSystem);
    //    observeAntiTheftSystem.Activate();


    //}

    //[TestGroup("Dynamic Test case sequence", "depends on preceding test case results")]
    //public void DynamicTestGroup()
    //{
    //    SimpleTest();
    //    if (TestModule.VerdictLastTestCase == Verdict.Passed)
    //    {
    //        SimpleTest2();
    //        // ��
    //    }
    //}

    //[TestCase]
    //public void LockStateDependsOnCrashDetection()
    //{
    //    // Test Pattern - Crash Detection function test
    //    CrashDetectionTest crashTest = new CrashDetectionTest();
    //    crashTest.Execute();
    //    // Change test pattern input parameter and re-execute
    //    crashTest.crashDetected = 0;
    //    crashTest.Execute();
    //}

    #region TestFunction
    //[TestFunction]
    //private void Report_SetTestHeaderInfo()
    //{
    //    string gkLibraryVersion = "1.0.0";
    //    // The title is written to the report
    //    Title = "LIN2.1 Conformance Test for IUT as Slave C#.NET Test Module\n";
    //    Description = "LIN2.1 OSI Layer 2 - Data Link Layer (L2),\n ";
    //    Description = "LIN2.1 OSI Layer 3 - Node Configuration & Network Management (NCNM).";

    //    Report.SetSetupInfo("Test Specification", "LIN2.1 Conformance Test Specification (September 28, 2022)");
    //    Report.SetSetupInfo("Capl Library Version: ", gkLibraryVersion);

    //    //Report.SetSUTInfo("LDF Name", IUTData_LDFName);
    //    //Report.SetSUTInfo("NCF Name", IUTData_NCFName);
    //    //Report.SetSUTInfo("IUT Name", IUTData_Name);
    //    //Report.SetSUTInfo("IUT Initial NAD", IUTData_NAD);
    //    //Report.SetSUTInfo("IUT Variant ID", IUTData_Variant);
    //    //Report.SetSUTInfo("LDF Name", Slave_DUT1);
    //    //Report.SetSUTInfo("LDF Name", Slave_DUT1);
    //    //Report.SetSUTInfo("LDF Name", Slave_DUT1);
    //    //Report.SetSUTInfo("LDF Name", Slave_DUT1);

    //}

    #endregion TestFunction End
}

//public class NetLibrary
//{
//    // Test cases need to be marked with an attribute:
//    [TestCase("Simple Test")]
//    public void SimpleTest()
//    {
//        // test case as shown for a .NET test module, see above
//    }

//    [TestFunction("SetValue")]
//    public void SetValue(int a)
//    {
//        NetworkDB.LIN_Master.TST_FRAME_2_Tx_Signal1.Value = a;

//    }


//}

//public class MyUserCheck : UserCheck
//{
//    public MyUserCheck(string title, string description) : base(title, description)
//    { }
//    [OnCANFrame(1, 0x64)]
//    public void FrameReceived1(CANFrame frame)
//    {
//        if (frame.DLC != 1)
//            ReportViolation("DLC check for frame 0x64 failed");
//    }



//}

//public class CrashDetectionTest : StateChange
//{
//    public CrashDetectionTest() { Wait = 200; }
//    [Input(typeof(NetworkDB.CrashDetected))]
//    public double crashDetected = 1;
//    [Expected(typeof(NetworkDB.LockState), Relation.Equal)]
//    public double lockState = 0;
//}

//[TestClass]
//public class TestCaseLibrary
//{
//    [Export] [TestCase] [BreakOnFail(true)]
//    public static void TestWithOwnExceptionHandling()
//    {
//        try
//        {
//            //Do something you need exception handling
//        }
//        catch (MyConcreteException)
//        {
//            //Do something inside your catch-block
//        }
//    }

//    //Override the ��System.Exception��-class
//    private class MyConcreteException : System.Exception { }
//}



//public class MyStateChange : StateChange
//{
//    public MyStateChange()
//    {
//        Wait = 100;
//    }
//    [Input(typeof(LightSwitch.OnOff))]
//    public double lightSwitch = 1;
//    [Expected(typeof(LightState.OnOff), Relation.Equal)]
//    public double lightState = 1;
//}






